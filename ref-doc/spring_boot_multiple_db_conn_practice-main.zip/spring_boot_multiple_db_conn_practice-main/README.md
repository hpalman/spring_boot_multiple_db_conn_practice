# spring_boot_multiple_db_conn_practice
spring boot 다중 데이터베이스 사용 연습하기

- MySQL, MyBatis 사용
